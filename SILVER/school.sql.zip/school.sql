-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 11, 2016 at 10:47 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `school`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `achievements`
-- 

CREATE TABLE `achievements` (
  `id` int(11) NOT NULL auto_increment,
  `imageName` varchar(200) NOT NULL,
  `plantname` varchar(200) default NULL,
  `directoryName` varchar(200) NOT NULL,
  `uploadtime` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=191 ;

-- 
-- Dumping data for table `achievements`
-- 

INSERT INTO `achievements` VALUES (19, '../gallery/DSCN7294.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (18, '../gallery/DSCN7293.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (17, '../gallery/DSCN7292.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (16, '../gallery/DSCN7291.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (15, '../gallery/DSCN7290.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (14, '../gallery/DSCN7289.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (13, '../gallery/DSCN7288.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (12, '../gallery/DSCN7287.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (114, '../gallery/IMG_0579.JPG', 'Plant-14', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (113, '../gallery/IMG_0578.JPG', 'Plant-14', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (112, '../gallery/IMG_0561.JPG', 'Plant-14', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (20, '../gallery/DSCN7295.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (21, '../gallery/DSCN7296.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (22, '../gallery/DSCN7297.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (23, '../gallery/DSCN7298.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (24, '../gallery/DSCN7299.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (25, '../gallery/DSCN7300.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (26, '../gallery/DSCN7301.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (27, '../gallery/DSCN7302.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (28, '../gallery/DSCN7303.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (29, '../gallery/DSCN7304.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (30, '../gallery/DSCN7305.JPG', 'Plant-1 Chakan', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (31, '../gallery/DSC02013.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (32, '../gallery/DSC02018.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (33, '../gallery/DSC02186.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (34, '../gallery/DSC02298.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (35, '../gallery/DSC02317.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (36, '../gallery/DSC02392.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (37, '../gallery/DSC02517.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (38, '../gallery/DSC06182.JPG', 'Plant-1 Chakan', 'Ganeshutsav', '12/18/2014');
INSERT INTO `achievements` VALUES (39, '../gallery/DSC03198.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (40, '../gallery/DSC03200.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (41, '../gallery/DSC07824.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (42, '../gallery/DSC07852.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (43, '../gallery/DSC07866.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (44, '../gallery/DSC07879.JPG', 'Plant-1 Chakan', 'Runathon-2014', '12/18/2014');
INSERT INTO `achievements` VALUES (189, '../gallery/IMG_20150118_151031.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (46, '../gallery/DSC_8953.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (47, '../gallery/DSC_8954.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (48, '../gallery/DSC_8956.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (49, '../gallery/DSC_8960.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (50, '../gallery/DSC_8961.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (51, '../gallery/DSC_8962.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (52, '../gallery/DSC_8963.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (53, '../gallery/DSC_8964.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (54, '../gallery/DSC_8965.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (55, '../gallery/DSC_8968.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (56, '../gallery/DSC_8969.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (57, '../gallery/DSC_8971.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (58, '../gallery/DSC_8973.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (59, '../gallery/DSC_8974.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (60, '../gallery/DSC_8975.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (61, '../gallery/DSC_8977.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (62, '../gallery/DSC_8978.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (63, '../gallery/DSC_8979.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (64, '../gallery/DSC_8980.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (65, '../gallery/DSC_8981.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (66, '../gallery/DSC_8982.JPG', 'Plant-3 Pantnagar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (181, '../gallery/DSCN8586.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (180, '../gallery/DSCN8584.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (179, '../gallery/DSCN8521.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (70, '../gallery/DSC08156.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (71, '../gallery/DSC08157.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (72, '../gallery/DSC08164.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (73, '../gallery/DSC08168.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (74, '../gallery/DSC08169.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (75, '../gallery/DSC08172.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (76, '../gallery/DSC08174.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (77, '../gallery/DSC08176.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (78, '../gallery/DSC08179.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (79, '../gallery/DSC08183.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (80, '../gallery/DSC08188.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (81, '../gallery/DSC08194.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (82, '../gallery/DSC08197.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (83, '../gallery/DSC08208.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (84, '../gallery/DSC08210.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (85, '../gallery/DSC08213.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (86, '../gallery/DSC08216.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (87, '../gallery/DSC08222.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (88, '../gallery/DSC08225.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (89, '../gallery/DSC08227.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (90, '../gallery/DSC08231.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (91, '../gallery/DSC08234.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (92, '../gallery/DSC08235.JPG', 'Plant-12 Manesar', 'Foundation', '12/18/2014');
INSERT INTO `achievements` VALUES (93, '../gallery/A.D 1.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (94, '../gallery/DSC04136.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (95, '../gallery/DSC04143.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (96, '../gallery/DSC04208.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (97, '../gallery/DSC04212.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (98, '../gallery/QUALITY YEAR 1.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (99, '../gallery/QUALITY YEAR 2.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (100, '../gallery/QUALITY YEAR 3.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (101, '../gallery/scan0032.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (102, '../gallery/scan0035.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (103, '../gallery/scan0038.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (104, '../gallery/scan0046.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (105, '../gallery/scan0049.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (106, '../gallery/scan0062.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (107, '../gallery/scan0083.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (108, '../gallery/scan0084.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (109, '../gallery/scan0124.JPG', 'Plant-12 Manesar', 'Annual', '12/18/2014');
INSERT INTO `achievements` VALUES (111, '../gallery/IMG_0560.JPG', 'Plant-14', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (115, '../gallery/IMG_0604.JPG', 'Plant-14', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (116, '../gallery/2013 043.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (117, '../gallery/2013 044.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (118, '../gallery/2013 045.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (119, '../gallery/2013 046.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (120, '../gallery/2013 047.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (121, '../gallery/2013 048.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (122, '../gallery/2013 049.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (123, '../gallery/2013 050.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (124, '../gallery/2013 051.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (125, '../gallery/2013 052.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (126, '../gallery/2013 053.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (127, '../gallery/2013 054.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (128, '../gallery/2013 056.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (129, '../gallery/2013 057.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (130, '../gallery/2013 058.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (131, '../gallery/2013 059.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (132, '../gallery/2013 060.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (133, '../gallery/2013 061.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (134, '../gallery/2013 062.JPG', 'Plant-14', 'Vastu', '01/14/2015');
INSERT INTO `achievements` VALUES (135, '../gallery/DSC00797.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (136, '../gallery/DSC00808.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (137, '../gallery/DSC00818.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (138, '../gallery/DSC00820.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (139, '../gallery/DSC00829.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (140, '../gallery/DSC00833.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (141, '../gallery/DSC00852.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (142, '../gallery/DSC00863.JPG', 'Plant-17', 'Foundation', '01/14/2015');
INSERT INTO `achievements` VALUES (143, '../gallery/Advik Front 2.jpg', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (144, '../gallery/Advik Front 3.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (145, '../gallery/Advik Front.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (146, '../gallery/Advik Meeting Room 1st Floor 2.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (147, '../gallery/Advik Meeting room 1st Floor.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (148, '../gallery/Advik Office 1st Floor.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (149, '../gallery/Advik Office Ground Floor.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (150, '../gallery/Advik PresDir Room (2).JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (151, '../gallery/Advik PresDir Room (3).JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (152, '../gallery/Advik PresDir Room.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (153, '../gallery/Advik Reception & Guest Waiting.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (154, '../gallery/Advik Shop Floor 1.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (155, '../gallery/Advik Shop Floor 2.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (156, '../gallery/Advik Shop Floor 3.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (157, '../gallery/Advik Shop Floor 4.JPG', 'Plant-17', 'Indonesia', '01/14/2015');
INSERT INTO `achievements` VALUES (190, '../gallery/IMG_20150118_153745.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (188, '../gallery/IMG_20150118_123657.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (184, '../gallery/DSCN8656.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (185, '../gallery/IMG_20150118_120248.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (186, '../gallery/IMG_20150118_120958.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (187, '../gallery/IMG_20150118_121059.jpg', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (183, '../gallery/DSCN8652.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (182, '../gallery/DSCN8604.JPG', 'Plant-1 Chakan', 'Experiential Learning', '01/20/2015');
INSERT INTO `achievements` VALUES (172, '../gallery/IMG_20150111_084027.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (173, '../gallery/IMG_20150111_084331.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (174, '../gallery/IMG_20150111_084339.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (175, '../gallery/IMG_20150111_084344.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (176, '../gallery/IMG_20150111_090348.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (177, '../gallery/WP_20150111_053.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');
INSERT INTO `achievements` VALUES (178, '../gallery/WP_20150111_054.jpg', 'Plant-1 Chakan', 'Runathon-2015', '01/14/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES (1, 'admin', 'admin', 'admin', 'admin@gmail.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `admission`
-- 

CREATE TABLE `admission` (
  `id` int(255) NOT NULL auto_increment,
  `title` text character set latin1 NOT NULL,
  `description` text character set latin1 NOT NULL,
  `fileUrl` varchar(100) collate utf8_unicode_ci default NULL,
  `uploadtime` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `admission`
-- 

INSERT INTO `admission` VALUES (4, 'All India Early Childhood Care & Education', '', 'admission.pdf', '2015-02-19', 1);
INSERT INTO `admission` VALUES (5, 'Application Form For Admission', '', 'Application Form For Admission.pdf', '2015-02-20', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `banner`
-- 

CREATE TABLE `banner` (
  `banner_id` int(11) NOT NULL auto_increment,
  `banner_name` varchar(255) NOT NULL,
  `banner_url` varchar(255) NOT NULL,
  `banner_date` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`banner_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `banner`
-- 

INSERT INTO `banner` VALUES (8, '1', '1.png', '1424350198', 1);
INSERT INTO `banner` VALUES (9, '2', '2.png', '1424350204', 1);
INSERT INTO `banner` VALUES (10, '3', '3.png', '1424350209', 1);
INSERT INTO `banner` VALUES (11, '4', '4.png', '1424350215', 1);
INSERT INTO `banner` VALUES (12, '5', '5.png', '1424350221', 1);
INSERT INTO `banner` VALUES (13, '6', '6.png', '1424350227', 1);
INSERT INTO `banner` VALUES (14, '7', '7.png', '1424350233', 1);
INSERT INTO `banner` VALUES (15, '8', '8.png', '1424350238', 1);
INSERT INTO `banner` VALUES (16, '9', '9.png', '1424350244', 1);
INSERT INTO `banner` VALUES (17, '10', '10.png', '1424350251', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `contact`
-- 

CREATE TABLE `contact` (
  `id` varchar(255) NOT NULL,
  `address` varchar(255) default NULL,
  `contact` varchar(255) default NULL,
  `mail` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `contact`
-- 

INSERT INTO `contact` VALUES ('1', '<p>Silver Bell Tree School, Mangalmurti Heights, Opp More Super Market, Kharadi, Pune - 411014.(Zensar IT Park)</p>', '+91 7755933267 / 020 65203267', 'info@silverbelltreeschool.com', '+ 91 9130488310');

-- --------------------------------------------------------

-- 
-- Table structure for table `courses`
-- 

CREATE TABLE `courses` (
  `id` int(255) NOT NULL auto_increment,
  `title` text character set latin1 NOT NULL,
  `description` text character set latin1 NOT NULL,
  `fileUrl` varchar(100) collate utf8_unicode_ci default NULL,
  `status` int(1) NOT NULL,
  `uploadtime` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `courses`
-- 

INSERT INTO `courses` VALUES (19, 'List Of Courses 1', '', 'silver-bell.pdf', 1, '2015-02-13');
INSERT INTO `courses` VALUES (20, 'Training for Teacher', '', 'Vodafone_ACMP3564606493.pdf', 1, '2015-02-14');

-- --------------------------------------------------------

-- 
-- Table structure for table `directoryimagefoldernamelist`
-- 

CREATE TABLE `directoryimagefoldernamelist` (
  `id` int(200) NOT NULL auto_increment,
  `directoryName` varchar(200) collate utf8_unicode_ci NOT NULL,
  `directoryLocation` varchar(256) collate utf8_unicode_ci NOT NULL,
  `createTime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `directoryimagefoldernamelist`
-- 

INSERT INTO `directoryimagefoldernamelist` VALUES (7, 'Childrens day 2014-15', '', '2015-04-14 01:19:25');
INSERT INTO `directoryimagefoldernamelist` VALUES (4, 'Sports Day 2014-15', '', '2015-04-14 00:57:39');
INSERT INTO `directoryimagefoldernamelist` VALUES (8, 'Republic Day 2014-15', '', '2015-04-14 01:19:42');
INSERT INTO `directoryimagefoldernamelist` VALUES (9, 'Art and Craft 2014-15', '', '2015-04-13 21:38:39');
INSERT INTO `directoryimagefoldernamelist` VALUES (10, 'Anual Day 2014-15', '', '2015-04-14 01:20:21');

-- --------------------------------------------------------

-- 
-- Table structure for table `news`
-- 

CREATE TABLE `news` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `thumb` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

-- 
-- Dumping data for table `news`
-- 

INSERT INTO `news` VALUES (24, '', NULL, 'DSCN1690.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (25, '', NULL, 'DSCN1693.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (26, '', NULL, 'DSCN1695.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (23, '', '', 'DSCN1689.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (31, '', NULL, 'DSCN1697.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (28, '', NULL, '_DSC2143.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (32, '', NULL, '_DSC2144.JPG', '1', '04/14/2015');
INSERT INTO `news` VALUES (33, '', NULL, '_DSC2348.JPG', '1', '04/14/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `notices`
-- 

CREATE TABLE `notices` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `event_date` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `notices`
-- 

INSERT INTO `notices` VALUES (23, 'Activity and Events for the month of February, 2015', 'NEW_ZENSIR_SCHOO1_notice_3.pdf', NULL, '1', '04/14/2015');
INSERT INTO `notices` VALUES (18, 'WITHOUT CHANGE THERE IS NO INNOVATION, CREATIVITY OR INCENTIVE FOR IMPROVEMENT. THOSE WHO INITIATE CHANGE WILL HAVE A BETTER OPPORTUNITY TO MANAGE THE CHANGE THAT IS INEVITABLE â€“ WILLIAM POLLARD', 'NEW_ZENSIR_SCHOO1_notice_2.pdf', NULL, '1', '04/14/2015');
INSERT INTO `notices` VALUES (21, 'Activity and Events for the month of January, 2015', 'NEW_ZENSIR_SCHOO1_notice_1.pdf', NULL, '1', '04/14/2015');
INSERT INTO `notices` VALUES (20, 'Activity and Events for the month of March, 2015', 'NEW_ZENSIR_SCHOOL_notice_march_april_notice_4.pdf', NULL, '1', '04/14/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `pages`
-- 

CREATE TABLE `pages` (
  `pages_id` int(11) NOT NULL auto_increment,
  `pages_name` varchar(255) NOT NULL,
  `pages_desc` text NOT NULL,
  PRIMARY KEY  (`pages_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `pages`
-- 

INSERT INTO `pages` VALUES (1, 'History', '<p>Today&rsquo;s Children are tomorrow&rsquo;s citizens. This is something that we have heard a lot of times. We believe in this statement completely.</p>\r\n<p>We provide a well balanced environment which focuses on shaping future leaders by offering a developmental approach. The foundation promotes discipline, Values, consistency, learning attitude, connect with the environment and most importantly sense of social life. We strongly believe that our country today needs a community</p>\r\n<p>The school is nurtured by the Director and Board of Trustees who come from various fields like Psychologists, Social Leaders, Engineers, Spiritual Leaders, Information Technology, Manufacturing, Real Estate and others.</p>\r\n<p>We started off as a pre-primary and have grown in last 4 years to Primary Grade 4. Every year we are growing like a blooming tree with consistency.</p>');
INSERT INTO `pages` VALUES (18, 'Privacy Policy', '<p>Marvel Solution has created this Privacy Policy to record and explain our commitment to privacy.All other trademarks, trade names, service marks and logos used on this website are the property of their respective owners.Marvel Solution has produced this privacy statement in order to reveal our firms dedication to privacy. The following discloses our information gathering and dissemination practices for&nbsp;[url=http://www.marvelsolution.com/]www.marvelsolution.com[/url]Our sites registration form requires you to give us contact information like your name and email address. We use this contact information from the registration form to send you detail about our company. Marvel Solution is not responsible for the privacy practices or the content of such Web sites.Marvel Solution website is designed in order to assist you in making informed decisions about our products and services. Marvel Solution is committed to ensuring that your privacy is protected. It is important to us that our customers retain their privacy while taking advantage of the products and services that we have to offer. We may collect your name, contact information, other demographic and related information to understand your needs and subsequently use this information to contact you. We may send you emails informing you about our new products and services. We will not disclose or sell any of your personal information to any third party unless we have your permission or are required by law to do so. Although we may use cookie technology to help you navigate our website efficiently we never use cookies to store personal information. Please be aware, however, that our website may contain link to other websites of interest and that the privacy practices of other websites may differ from those of Marvel Solution. We hold no responsibility for the protection and privacy of any information that you provide at these websites whilst visiting these websites and all such websites are not governed by this privacy policy.</p>');
INSERT INTO `pages` VALUES (17, 'Thought Of The Day', '<p><strong>&ldquo;The only real prison is fear, and the only real freedom is freedom from fear&rdquo;</strong></p>');
INSERT INTO `pages` VALUES (2, 'Director Speech', '<p>&ldquo;Education is a key to success.&rdquo;&nbsp; It gives us knowledge of the world around us, while opening doors to brilliant career opportunities. Education builds confidence to make decisions to face life, and to accept success and failures. The best way to reach career success is to map out a strategy and set goals. Education can be a source that could lead someone for a better future. Having seventeen or eighteen years of waking up early in the morning, doing homeworks &amp; projects &amp; staying late at night to study for exams is not an easy task to do. But, for you, what is success? For some, success is the accomplishment of the goal aimed by a person. But, for me, success means that is one way of promoting to others that, I have determination &amp; patience with what I am doing. Also, it is telling to others that I am willing to do everything just to reach my goal. Also, through education we can learn more &amp; improve ourselves in whatever field we do have.</p>\r\n<p>The characters &amp; the willingness of an individual also affect one&rsquo;s ability to become successful. Through education, it helps in the formation of character with desirable qualities to become successful person. As a whole, education can give us a better life in the future if we do.</p>');
INSERT INTO `pages` VALUES (3, 'Mision', '<p>To fulfill the vision, The Silver Bell Tree School provides a complete balanced environment in which each student discovers and understands his full potential and develop skills. The school must maintain the highest academic and sports standards. The school must also maintain its pursuit of knowledge and skill.</p>');
INSERT INTO `pages` VALUES (4, 'Vision', '<p>The Silver Bell Tree School aims to be an institution of Knowledge and Wisdom with complete dedication towards creating leaders of the future.</p>');
INSERT INTO `pages` VALUES (10, 'youtube', '<p>youtube.com</p>');
INSERT INTO `pages` VALUES (15, 'G+', '<p>plus.google.com</p>');
INSERT INTO `pages` VALUES (5, 'Our Values', '<p><!--[if gte mso 9]><xml>\r\n <w:WordDocument>\r\n  <w:View>Normal</w:View>\r\n  <w:Zoom>0</w:Zoom>\r\n  <w:TrackMoves/>\r\n  <w:TrackFormatting/>\r\n  <w:PunctuationKerning/>\r\n  <w:ValidateAgainstSchemas/>\r\n  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\r\n  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>\r\n  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\r\n  <w:DoNotPromoteQF/>\r\n  <w:LidThemeOther>EN-IN</w:LidThemeOther>\r\n  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>\r\n  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>\r\n  <w:Compatibility>\r\n   <w:BreakWrappedTables/>\r\n   <w:SnapToGridInCell/>\r\n   <w:WrapTextWithPunct/>\r\n   <w:UseAsianBreakRules/>\r\n   <w:DontGrowAutofit/>\r\n   <w:SplitPgBreakAndParaMark/>\r\n   <w:DontVertAlignCellWithSp/>\r\n   <w:DontBreakConstrainedForcedTables/>\r\n   <w:DontVertAlignInTxbx/>\r\n   <w:Word11KerningPairs/>\r\n   <w:CachedColBalance/>\r\n  </w:Compatibility>\r\n  <m:mathPr>\r\n   <m:mathFont m:val=\\"Cambria Math\\"/>\r\n   <m:brkBin m:val=\\"before\\"/>\r\n   <m:brkBinSub m:val=\\"--\\"/>\r\n   <m:smallFrac m:val=\\"off\\"/>\r\n   <m:dispDef/>\r\n   <m:lMargin m:val=\\"0\\"/>\r\n   <m:rMargin m:val=\\"0\\"/>\r\n   <m:defJc m:val=\\"centerGroup\\"/>\r\n   <m:wrapIndent m:val=\\"1440\\"/>\r\n   <m:intLim m:val=\\"subSup\\"/>\r\n   <m:naryLim m:val=\\"undOvr\\"/>\r\n  </m:mathPr></w:WordDocument>\r\n</xml><![endif]--></p>\r\n<p><!--[if gte mso 9]><xml>\r\n <w:LatentStyles DefLockedState=\\"false\\" DefUnhideWhenUsed=\\"true\\"\r\n  DefSemiHidden=\\"true\\" DefQFormat=\\"false\\" DefPriority=\\"99\\"\r\n  LatentStyleCount=\\"267\\">\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"0\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Normal\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"heading 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 7\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 8\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"9\\" QFormat=\\"true\\" Name=\\"heading 9\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 7\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 8\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" Name=\\"toc 9\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"35\\" QFormat=\\"true\\" Name=\\"caption\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"10\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Title\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"1\\" Name=\\"Default Paragraph Font\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"11\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Subtitle\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"22\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Strong\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"20\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Emphasis\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"59\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Table Grid\\"/>\r\n  <w:LsdException Locked=\\"false\\" UnhideWhenUsed=\\"false\\" Name=\\"Placeholder Text\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"1\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"No Spacing\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" UnhideWhenUsed=\\"false\\" Name=\\"Revision\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"34\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"List Paragraph\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"29\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Quote\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"30\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Intense Quote\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 1\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 2\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 3\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 4\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 5\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"60\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Shading Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"61\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light List Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"62\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Light Grid Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"63\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 1 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"64\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Shading 2 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"65\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 1 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"66\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium List 2 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"67\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 1 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"68\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 2 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"69\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Medium Grid 3 Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"70\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Dark List Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"71\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Shading Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"72\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful List Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"73\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" Name=\\"Colorful Grid Accent 6\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"19\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Subtle Emphasis\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"21\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Intense Emphasis\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"31\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Subtle Reference\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"32\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Intense Reference\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"33\\" SemiHidden=\\"false\\"\r\n   UnhideWhenUsed=\\"false\\" QFormat=\\"true\\" Name=\\"Book Title\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"37\\" Name=\\"Bibliography\\"/>\r\n  <w:LsdException Locked=\\"false\\" Priority=\\"39\\" QFormat=\\"true\\" Name=\\"TOC Heading\\"/>\r\n </w:LatentStyles>\r\n</xml><![endif]--><!--[if gte mso 10]>\r\n<style>\r\n /* Style Definitions */\r\n table.MsoNormalTable\r\n	{mso-style-name:\\"Table Normal\\";\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	mso-style-noshow:yes;\r\n	mso-style-priority:99;\r\n	mso-style-qformat:yes;\r\n	mso-style-parent:\\"\\";\r\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\n	mso-para-margin-top:0cm;\r\n	mso-para-margin-right:0cm;\r\n	mso-para-margin-bottom:10.0pt;\r\n	mso-para-margin-left:0cm;\r\n	line-height:115%;\r\n	mso-pagination:widow-orphan;\r\n	font-size:11.0pt;\r\n	font-family:\\"Calibri\\",\\"sans-serif\\";\r\n	mso-ascii-font-family:Calibri;\r\n	mso-ascii-theme-font:minor-latin;\r\n	mso-fareast-font-family:\\"Times New Roman\\";\r\n	mso-fareast-theme-font:minor-fareast;\r\n	mso-hansi-font-family:Calibri;\r\n	mso-hansi-theme-font:minor-latin;}\r\n</style>\r\n<![endif]--></p>\r\n<p style=\\"margin: 0cm; margin-bottom: .0001pt; line-height: 18.0pt; background: white;\\"><strong><span lang=\\"EN-US\\" style=\\"font-size: 17pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851; letter-spacing: -0.75pt;\\">Aim High</span></strong></p>\r\n<p style=\\"margin-top: 0cm; margin-right: 0cm; margin-bottom: 11.25pt; margin-left: 0cm; line-height: 18.0pt; background: white;\\"><span lang=\\"EN-US\\" style=\\"font-size: 8.5pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851;\\">Our schools are dedicated to teaching students to be involved, active learners who work hard, think critically and creatively, and communicate effectively. We emphasize high expectations for all students, and support them to reach their full potential in all aspects of achievement, especially in academics, arts, sports, social skills and civic participation, all of which prepare students for success in their lives after high school.</span></p>\r\n<p style=\\"margin: 0cm; margin-bottom: .0001pt; line-height: 18.0pt; background: white;\\"><strong><span lang=\\"EN-US\\" style=\\"font-size: 17pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851; letter-spacing: -0.75pt;\\">Excellence in Teaching</span></strong></p>\r\n<p style=\\"margin-top: 0cm; margin-right: 0cm; margin-bottom: 11.25pt; margin-left: 0cm; line-height: 18.0pt; background: white;\\"><span lang=\\"EN-US\\" style=\\"font-size: 8.5pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851;\\">Passionate, knowledgeable, skillful teachers are the core strength of our school system. We expect our faculty and staff to provide a dynamic and rewarding learning experience for students. Excellent teaching begins with strong relationships between faculty and students and is nurtured by collaboration among colleagues. We are committed to supporting a professional community that creates and sustains an atmosphere of intellectual excitement, innovative instruction and personal growth.</span></p>\r\n<p style=\\"margin: 0cm; margin-bottom: .0001pt; line-height: 18.0pt; background: white;\\"><strong><span lang=\\"EN-US\\" style=\\"font-size: 17pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851; letter-spacing: -0.75pt;\\">Collaboration</span></strong></p>\r\n<p style=\\"margin-top: 0cm; margin-right: 0cm; margin-bottom: 11.25pt; margin-left: 0cm; line-height: 18.0pt; background: white;\\"><span lang=\\"EN-US\\" style=\\"font-size: 8.5pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851;\\">Through collaboration we find new sources of learning and strength. We seek out partnerships with community organizations that add value to our school system. We urge and support collaboration and exchange within and across our school community.</span></p>\r\n<p style=\\"margin: 0cm; margin-bottom: .0001pt; line-height: 18.0pt; background: white;\\"><strong><span lang=\\"EN-US\\" style=\\"font-size: 17pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851; letter-spacing: -0.75pt;\\">Respect for Human Differences</span></strong></p>\r\n<p style=\\"margin-top: 0cm; margin-right: 0cm; margin-bottom: 11.25pt; margin-left: 0cm; line-height: 18.0pt; background: white;\\"><span lang=\\"EN-US\\" style=\\"font-size: 8.5pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851;\\">We are committed to acknowledging and celebrating the diversity within our community while affirming the importance of our common humanity. By promoting a safe environment for questioning and challenge, we foster the growth and value that comes from different perspectives, cultures and experiences. Our commitment is to create an atmosphere of safety in which to acknowledge and express difference while advancing true acceptance and respect for all.</span></p>\r\n<p style=\\"margin: 0cm; margin-bottom: .0001pt; line-height: 18.0pt; background: white;\\"><strong><span lang=\\"EN-US\\" style=\\"font-size: 17pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851; letter-spacing: -0.75pt;\\">Educational Equity</span></strong></p>\r\n<p style=\\"margin-top: 0cm; margin-right: 0cm; margin-bottom: 11.25pt; margin-left: 0cm; line-height: 18.0pt; background: white;\\"><span lang=\\"EN-US\\" style=\\"font-size: 8.5pt; font-family: \\''Verdana\\'',\\''sans-serif\\''; color: #5d5851;\\">We are committed to identifying and eliminating barriers to educational achievement in our schools. To this end, we create policies and practices that are fair and just and provide educational opportunities to ensure that every student, regardless of race, color, religion, gender, disability, or economic status, meets our standards for achievement, participation and growth.</span></p>');
INSERT INTO `pages` VALUES (6, 'twitter', '<p>www.twitter.com</p>');
INSERT INTO `pages` VALUES (7, 'Quick Contact', '<p>www.facebook.com/marvelsolution</p>');
INSERT INTO `pages` VALUES (16, 'About Us', '<p>At Tyres King, we provide tyres for various types of vehicles, such as: Trucks, Vans, four wheel drive vehicles, Forklift and cars.</p>\r\n<p>Drive your vehicle to our tyre centre, where our staff will help you choose the best type of tyres to fit to your vehicle depending on your requirements. As you wait, a member of staff can have your set of new tyres fiitted and balanced in a very short time, ready for you to drive away.</p>\r\n<p>When it comes to choosing your new tyres, we have a large range of various brands in stock.</p>\r\n<p>Our personal guarantee is honesty at ALL times.</p>');
INSERT INTO `pages` VALUES (8, 'twitter', '<p>twitter.com</p>');
INSERT INTO `pages` VALUES (13, 'Disclaimer', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n<p>Excepteur sint occaecat cupidatat non proident, sunt in cim id est laborum. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi.</p>');
INSERT INTO `pages` VALUES (14, 'Pivacy Policy', '<p>www.facebook.com</p>');
INSERT INTO `pages` VALUES (9, 'linkedin', '<p>linkedin.com</p>');

-- --------------------------------------------------------

-- 
-- Table structure for table `plantphotos_gallery_details`
-- 

CREATE TABLE `plantphotos_gallery_details` (
  `id` int(11) NOT NULL auto_increment,
  `imageName` varchar(200) NOT NULL,
  `plantname` varchar(200) default NULL,
  `directoryName` varchar(200) NOT NULL,
  `uploadtime` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

-- 
-- Dumping data for table `plantphotos_gallery_details`
-- 

INSERT INTO `plantphotos_gallery_details` VALUES (237, '_DSC2130.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (238, '_DSC2161.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (239, '_DSC2170.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (240, '_DSC2177.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (241, '_DSC2196.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (242, '_DSC2237.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (243, '_DSC2356.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (236, '_DSC2125.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (244, '_DSC7245.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (234, '_DSC2119.JPG', NULL, 'Anual Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (233, 'DSC01085.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (231, 'DSC01105.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (232, 'DSC01094.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (221, 'DSC01074.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (222, 'DSC01077.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (223, 'DSC01080.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (224, 'DSC01083.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (225, 'DSC01075.JPG', NULL, 'Republic Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (191, 'DSC00924.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (195, 'DSC00927.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (194, 'DSC00930.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (196, 'DSCN1434.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (197, 'DSCN1445.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (198, 'DSCN1449.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (199, 'DSCN1454.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (200, 'DSCN1459.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (201, 'DSCN1463.JPG', NULL, 'Sports Day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (202, 'DSC00567.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (203, 'DSC00782.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (204, 'DSC00822.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (205, 'DSCN1368.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (206, 'DSCN1371.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (210, 'DSCN1372.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (209, 'DSCN1376.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (211, 'DSCN1374.JPG', NULL, 'Childrens day 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (212, '_DSC7140.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (213, '_DSC7143.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (214, '_DSC7152.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (215, '_DSC7162.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (217, '_DSC7163.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (218, '_DSC7164.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (219, '_DSC7166.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');
INSERT INTO `plantphotos_gallery_details` VALUES (220, '_DSC7181.JPG', NULL, 'Art and Craft 2014-15', '04/14/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `testimonials`
-- 

CREATE TABLE `testimonials` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `status` int(1) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `testimonials`
-- 

INSERT INTO `testimonials` VALUES (8, 'P.Vinod Prabhu & Mrs. Aishwarya ( Parent of Pranavi  Iyer )', '<p>We are satisfied with the teaching &amp; care taking in the school. We with whole heartedly thank for the efforts.</p>', 1, '04/14/2015');
INSERT INTO `testimonials` VALUES (7, 'Mr.Kadam (Parent of Vaibhav Kadam)', '<p>The school is very good. Teacher&rsquo;s are very helpful and Co-operative. My child has learned good manners in the school. I am very happy with the studies &amp; staff of the school.</p>', 1, '04/14/2015');
INSERT INTO `testimonials` VALUES (9, 'Mrs. Phalak (Parent of Shubhra)', '<p>We are very pleased to take admission in the school, were we had intimated that our child needs extra attention &amp; the school staff had taken the same. We have seen improvement in our daughter. We are happy to continue her school for the next year&rsquo;s too.</p>', 1, '04/14/2015');
INSERT INTO `testimonials` VALUES (10, 'Mrs. Neeta Thopate (Parent of Palak Thopate)', '<p>Silver Bell Tree School is very good &amp; suitable for the school as well as for the students which resembles growth. Activities &amp; discipline is good in school. Teachers take good care of every student.</p>', 1, '04/14/2015');
INSERT INTO `testimonials` VALUES (11, 'Mrs. Kelkar ( Parent of Shravani)', '<p>I give 5 Stars for Teaching facility, teachers, Co curricular activities &amp; Art Craft exhibition.</p>', 1, '04/14/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `timetable`
-- 

CREATE TABLE `timetable` (
  `id` int(255) NOT NULL auto_increment,
  `title` text character set latin1 NOT NULL,
  `description` text character set latin1 NOT NULL,
  `fileUrl` varchar(100) collate utf8_unicode_ci default NULL,
  `uploadtime` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `timetable`
-- 

INSERT INTO `timetable` VALUES (8, 'Time Table for class Nursery', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_nursery.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (9, 'Time Table for class U.K.G', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_UKG.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (10, 'Time Table for class Play Group', '', 'NEW_ZENSIR_SCHOOL_Time_Table_for_play_group.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (7, 'Time Table for class L.K.G', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_LKG.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (16, 'Time Table for class 3rd', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_3std.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (15, 'Time Table for class 2nd', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_2std.pdf', '2015-04-14', 0);
INSERT INTO `timetable` VALUES (14, 'Time Table for class 1st', '', 'NEW_ZENSIR_SCHOOL_Time_table_for_1std.pdf', '2015-04-14', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `video`
-- 

CREATE TABLE `video` (
  `id` int(11) NOT NULL auto_increment,
  `ifram` varchar(1000) default NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `video`
-- 

INSERT INTO `video` VALUES (3, '<iframe width="560" height="315" src="https://www.youtube.com/embed/nPhHtahBlyI" frameborder="0" allowfullscreen></iframe>', 1);
